package com.teknodate.ozellistview.classes;

public class Kisi {

    public Kisi(String parametre1, String parametre2) {
        this.ad = parametre1;
        this.soyad=parametre2;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String ad;
    public String soyad;



}
