package com.teknodate.ozellistview.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.teknodate.ozellistview.R;
import com.teknodate.ozellistview.classes.Kisi;
import com.teknodate.ozellistview.helpers.OzelAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public final List<Kisi> kisiler=new ArrayList<Kisi>();

    public ListView listemiz;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kisiler.add(new Kisi("BARACK","OBAMA"));
        kisiler.add(new Kisi("DONALD","TRUMP"));
        kisiler.add(new Kisi("VLADIMIR","PUTİN"));

        listemiz=findViewById(R.id.listview);

        OzelAdapter adaptor = new OzelAdapter(this,kisiler);

        listemiz.setAdapter(adaptor);
    }
}
